//
//  AppDelegate.h
//  AddStarAnimationDemo
//
//  Created by dandy_zhouli on 2021/1/6.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@property (strong, nonatomic) UIWindow *window;
@end

