//
//  ViewController.m
//  AddStarAnimationDemo
//
//  Created by dandy_zhouli on 2021/1/6.
//

#import "ViewController.h"
#import "XMAddAttentionAnimation.h"

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UILabel *starCountL;
@property (nonatomic, assign) CGPoint endPoint;
@end

@implementation ViewController

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 30;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuseIdentifier = @"reuseIdentifier";
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    cell.textLabel.text = [NSString stringWithFormat:@"第%ld行", indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    CGPoint subviewPoint = [cell convertPoint:cell.textLabel.frame.origin toView:[UIApplication sharedApplication].delegate.window];
    NSLog(@"%@", [UIApplication sharedApplication].delegate.window);
    [[XMAddAttentionAnimation shared] animateWithView:cell.textLabel duration:0.4 from:subviewPoint to:self.endPoint complete:^(BOOL flag) {
        NSLog(@"XMAddAttentionAnimation::flag = %d", flag);
        
        // 让关注的那个label闪动一下
         NSString *scalAnimationKey = @"scalAnimationKey";
         CALayer *starLayer = self.starCountL.layer;
         if ([starLayer animationForKey:scalAnimationKey]) {// 如果之前动画没结束，则需移除
             [starLayer removeAnimationForKey:scalAnimationKey];
         }
        CABasicAnimation *scalAnimation = [CABasicAnimation animationWithKeyPath:@"transform"];
        scalAnimation.fromValue = [NSValue valueWithCATransform3D:CATransform3DIdentity];
        scalAnimation.toValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(0.75, 0.75, 1)];
        scalAnimation.autoreverses = YES;
        scalAnimation.removedOnCompletion = YES; // 结束后会移除动画，就不用手动移除了。
        scalAnimation.fillMode = kCAFillModeRemoved;//动画开始前和动画结束后,动画对layer都没有影响
        scalAnimation.duration = 0.125;
        [starLayer addAnimation:scalAnimation forKey:scalAnimationKey];
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.endPoint = CGPointMake([UIScreen mainScreen].bounds.size.width - 50, 80);
    self.starCountL = [[UILabel alloc] initWithFrame:CGRectMake(self.endPoint.x, self.endPoint.y, 35, 35)];
    [self.view addSubview:self.starCountL];
    self.starCountL.backgroundColor = [UIColor redColor];
    self.starCountL.text = @"15";
    self.starCountL.textAlignment = NSTextAlignmentCenter;
    self.starCountL.textColor = [UIColor whiteColor];
    
    UITableView *tablveiw = [[UITableView alloc] initWithFrame:CGRectMake(0, 120, 400, 600) style:UITableViewStylePlain];
    [self.view addSubview:tablveiw];
    tablveiw.delegate = self;
    tablveiw.dataSource = self;
}
@end
