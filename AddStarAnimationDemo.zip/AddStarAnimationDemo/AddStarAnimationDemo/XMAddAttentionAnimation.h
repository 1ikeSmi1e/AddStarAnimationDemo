//
//  XMAddAttentionAnimation.h
//  GIveLikeAnimation
//
//  Created by xuwen_chen on 2020/12/8.
//  Copyright © 2020 张竟巍. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XMAddAttentionAnimation : NSObject

+ (XMAddAttentionAnimation *)shared;
- (void)animateWithView:(UIView *)animateView duration:(CFTimeInterval)duration from:(CGPoint)beginPoint to:(CGPoint)endPoint complete:(void (^)(BOOL flag))completion;
@end

NS_ASSUME_NONNULL_END
