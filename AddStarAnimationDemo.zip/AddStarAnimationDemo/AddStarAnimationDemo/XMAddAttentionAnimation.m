//
//  XMAddAttentionAnimation.m
//  GIveLikeAnimation
//
//  Created by xuwen_chen on 2020/12/8.
//  Copyright © 2020 张竟巍. All rights reserved.
//

#import "XMAddAttentionAnimation.h"

@interface XMAddAttentionAnimation()<CAAnimationDelegate>
@property (nonatomic, strong) NSMutableDictionary *animateInfo;
@end

@implementation XMAddAttentionAnimation

#pragma mark - 单例方法
static XMAddAttentionAnimation *sharedInstance;
+ (id)allocWithZone:(struct _NSZone *)zone
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [super allocWithZone:zone];
    });
    
    return sharedInstance;
}

+ (XMAddAttentionAnimation *)shared
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[XMAddAttentionAnimation alloc]init];
    });
    
    return sharedInstance;
}


- (void)animationDidStart:(CAAnimationGroup *)anim{}

- (void)animationDidStop:(CAAnimationGroup *)anim finished:(BOOL)flag{
    
    UIView *currentView = nil;
    void (^completion)(BOOL flag) = nil;
    for (NSNumber *animteViewHash in self.animateInfo.allKeys) {
        
        CAAnimationGroup *group = self.animateInfo[animteViewHash][@"animation"];
        if ([group.animations isEqualToArray:anim.animations]) {
            currentView = self.animateInfo[animteViewHash][@"view"];
            UIView *subView = self.animateInfo[animteViewHash][@"animateView"];
            completion = self.animateInfo[animteViewHash][@"completion"];
            [subView.layer removeAnimationForKey:NSStringFromClass(self.class)];
            subView.hidden = YES;
            [subView removeFromSuperview];
            break;
        }
    }
    !completion ?: completion(flag);
    [self.animateInfo removeObjectForKey:@(currentView.hash)];
}

- (void)animateWithView:(UIView *)animateView duration:(CFTimeInterval)duration from:(CGPoint)beginPoint to:(CGPoint)endPoint complete:(void (^)(BOOL flag))completion{
    // 正在动画，不允许新动画
    NSDictionary *animateInfo = self.animateInfo[@(animateView.hash)];
    if (animateInfo) {
        return;
    }
    
    CGPoint subviewPoint = [animateView.superview convertPoint:animateView.frame.origin toView:[UIApplication sharedApplication].delegate.window];
    CGRect subviewFrame = CGRectMake(subviewPoint.x, subviewPoint.y, 40, 40);
    UIImageView *subView = [[UIImageView alloc] initWithFrame:subviewFrame];
    [[UIApplication sharedApplication].delegate.window addSubview:subView];
    subView.image = [UIImage imageNamed:@"Ballon_Star_red.png"];

    if (duration <= 0) {
        duration = 0.4;
    }
    // 1.大小缩放动画
    CABasicAnimation *scalAnimation = [CABasicAnimation animationWithKeyPath:@"transform"];
    scalAnimation.fromValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(0.6, 0.6, 1)];
    scalAnimation.toValue = [NSValue valueWithCATransform3D:CATransform3DIdentity];
    scalAnimation.removedOnCompletion = NO;
    scalAnimation.fillMode = kCAFillModeForwards;
    scalAnimation.duration = duration;
    
    // 2.轨迹动画
    CGFloat controlPointX = endPoint.x - (endPoint.x - beginPoint.x)/2;
    UIBezierPath *path = [[UIBezierPath alloc] init];
    [path moveToPoint:beginPoint];
    [path addQuadCurveToPoint:endPoint controlPoint:CGPointMake(controlPointX, endPoint.y - 150)];
    
    CAKeyframeAnimation *pathAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    pathAnimation.path = path.CGPath;
    pathAnimation.duration = duration;
    pathAnimation.autoreverses = NO;
    pathAnimation.removedOnCompletion = NO;
    pathAnimation.fillMode = kCAFillModeForwards;
    pathAnimation.repeatCount = 0;
    pathAnimation.calculationMode = kCAAnimationLinear;

    // 3.组合动画
    CAAnimationGroup *groupAnimate = [CAAnimationGroup animation];
    groupAnimate.autoreverses = NO;
    groupAnimate.fillMode = kCAFillModeForwards;
    groupAnimate.duration = duration;
    groupAnimate.removedOnCompletion = NO;
    groupAnimate.animations = @[pathAnimation,scalAnimation];
    
    XMAddAttentionAnimation *animationManager = [[XMAddAttentionAnimation alloc] init];
    groupAnimate.delegate = animationManager;// 这个delegate在动画移除后才会解除引用，所以外部不需要强引用animationManager
    [subView.layer addAnimation:groupAnimate forKey:NSStringFromClass(self.class)];
    
    NSDictionary *info = @{@"view" : animateView,
                           @"animateView" : subView ,
                           @"isAnimating": @YES,
                           @"animation" : groupAnimate ,
                           @"completion" :completion
    };
    self.animateInfo[@(animateView.hash)] = info;
}


- (NSMutableDictionary *)animateInfo
{
    if (!_animateInfo) {
        self.animateInfo = [NSMutableDictionary dictionary];
    }
    return _animateInfo;
}
@end
